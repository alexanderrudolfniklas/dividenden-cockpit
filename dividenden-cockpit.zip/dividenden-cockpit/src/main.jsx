import React, { useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { CalendarDays, Euro, TrendingUp, Target, Wallet, Plus, Search, ShieldCheck, Globe2 } from 'lucide-react';
import './styles.css';

const holdings = [
  { company: 'Allianz', ticker: 'ALV', country: 'Deutschland', sector: 'Versicherung', shares: 18, price: 242, dividend: 13.8, frequency: 'jährlich', months: ['Mai'], tax: 26.38 },
  { company: 'Enbridge', ticker: 'ENB', country: 'Kanada', sector: 'Energie / Pipeline', shares: 90, price: 35, dividend: 2.55, frequency: 'quartalsweise', months: ['Mär', 'Jun', 'Sep', 'Dez'], tax: 25 },
  { company: 'Realty Income', ticker: 'O', country: 'USA', sector: 'REIT', shares: 75, price: 52, dividend: 3.08, frequency: 'monatlich', months: ['Jan','Feb','Mär','Apr','Mai','Jun','Jul','Aug','Sep','Okt','Nov','Dez'], tax: 26.38 },
  { company: 'OMV', ticker: 'OMV', country: 'Österreich', sector: 'Energie', shares: 55, price: 41, dividend: 5.05, frequency: 'jährlich', months: ['Jun'], tax: 27.5 },
  { company: 'Johnson & Johnson', ticker: 'JNJ', country: 'USA', sector: 'Gesundheit', shares: 25, price: 148, dividend: 4.96, frequency: 'quartalsweise', months: ['Mär', 'Jun', 'Sep', 'Dez'], tax: 26.38 },
  { company: 'Vår Energi', ticker: 'VAR', country: 'Norwegen', sector: 'Energie', shares: 600, price: 3.1, dividend: 0.23, frequency: 'quartalsweise', months: ['Feb', 'Mai', 'Aug', 'Nov'], tax: 25 },
];
const monthOrder = ['Jan','Feb','Mär','Apr','Mai','Jun','Jul','Aug','Sep','Okt','Nov','Dez'];
const fmt = v => new Intl.NumberFormat('de-DE', { style:'currency', currency:'EUR', maximumFractionDigits:0 }).format(v);
const annualGross = h => h.shares * h.dividend;
const annualNet = h => annualGross(h) * (1 - h.tax / 100);
const monthlyNet = h => annualNet(h) / h.months.length;
const monthlyGross = h => annualGross(h) / h.months.length;
const yoc = h => h.dividend / h.price * 100;

function App() {
  const [tab, setTab] = useState('dashboard');
  const gross = useMemo(() => holdings.reduce((s,h)=>s+annualGross(h),0), []);
  const net = useMemo(() => holdings.reduce((s,h)=>s+annualNet(h),0), []);
  const avg = net / 12;
  const target = 6000;
  const progress = Math.round(net / target * 100);
  const monthlyData = monthOrder.map(month => ({
    month,
    brutto: Math.round(holdings.filter(h=>h.months.includes(month)).reduce((s,h)=>s+monthlyGross(h),0)),
    netto: Math.round(holdings.filter(h=>h.months.includes(month)).reduce((s,h)=>s+monthlyNet(h),0))
  }));
  const countryData = Object.values(holdings.reduce((acc,h)=>{ acc[h.country] ||= { name:h.country, value:0 }; acc[h.country].value += annualNet(h); return acc; }, {})).map(d=>({...d, value:Math.round(d.value)}));
  const top = [...holdings].sort((a,b)=>annualNet(b)-annualNet(a)).slice(0,5);

  return <main className="app">
    <header className="hero">
      <div>
        <div className="pill"><Wallet size={16}/> Persönliches Dividenden-Cockpit</div>
        <h1>Dein Cashflow auf einen Blick</h1>
        <p>Fokus auf Dividenden, Netto-Cashflow, Monatsplanung und Zielerreichung — nicht auf hektisches Trading.</p>
      </div>
      <div className="actions"><button><Plus size={16}/> Position hinzufügen</button><button className="secondary"><Search size={16}/> Aktie suchen</button></div>
    </header>
    <nav className="tabs">{['dashboard','portfolio','kalender','ziele'].map(t=><button key={t} className={tab===t?'active':''} onClick={()=>setTab(t)}>{t[0].toUpperCase()+t.slice(1)}</button>)}</nav>

    {tab==='dashboard' && <section className="stack">
      <div className="kpis"><Kpi icon={<Euro/>} label="Jahresdividende netto" value={fmt(net)} sub={`${fmt(gross)} brutto erwartet`}/><Kpi icon={<CalendarDays/>} label="Monatsdurchschnitt" value={fmt(avg)} sub="netto pro Monat"/><Kpi icon={<Target/>} label="Zielerreichung" value={`${progress}%`} sub={`Ziel: ${fmt(target)} netto/Jahr`}/><Kpi icon={<TrendingUp/>} label="Ø Yield on Cost" value={`${(holdings.reduce((s,h)=>s+yoc(h),0)/holdings.length).toFixed(1)}%`} sub="auf Beispiel-Einstandskurse"/></div>
      <div className="grid twoone"><Card title="Dividenden nach Monaten" sub="Brutto und netto erwartete Ausschüttungen"><div className="chart"><ResponsiveContainer><BarChart data={monthlyData}><XAxis dataKey="month" stroke="#94a3b8"/><YAxis stroke="#94a3b8"/><Tooltip contentStyle={{background:'#020617',border:'1px solid #334155',borderRadius:16}}/><Bar dataKey="brutto" fill="#64748b" radius={[8,8,0,0]}/><Bar dataKey="netto" fill="#34d399" radius={[8,8,0,0]}/></BarChart></ResponsiveContainer></div></Card><Card title="Top-Zahler" sub="nach erwarteter Netto-Jahresdividende">{top.map((h,i)=><div className="row" key={h.ticker}><div><b>{i+1}. {h.company}</b><small>{h.country} · {h.sector}</small></div><strong>{fmt(annualNet(h))}</strong></div>)}</Card></div>
      <div className="grid half"><Card title="Regionen-Mix" sub="Netto-Dividenden nach Ländern"><div className="chart small"><ResponsiveContainer><PieChart><Pie data={countryData} dataKey="value" nameKey="name" outerRadius={90} label>{countryData.map((e,i)=><Cell key={e.name} fill={['#34d399','#60a5fa','#fbbf24','#f87171','#a78bfa'][i%5]}/>)}</Pie><Tooltip contentStyle={{background:'#020617',border:'1px solid #334155',borderRadius:16}}/></PieChart></ResponsiveContainer></div></Card><Card title="Jahresziel" sub={`Ziel: ${fmt(target)} netto Dividende pro Jahr`}><div className="goal"><span>{fmt(net)} erreicht</span><span>{progress}%</span></div><div className="bar"><i style={{width:`${progress}%`}}/></div><div className="insights"><Insight icon={<ShieldCheck/>} title="Netto-Fokus" text="Quellensteuer und Abgeltung werden je Position mitgedacht."/><Insight icon={<Globe2/>} title="Länderblick" text="USA, Kanada, Norwegen und Europa sauber getrennt."/></div></Card></div>
    </section>}
    {tab==='portfolio' && <Portfolio/>}
    {tab==='kalender' && <Calendar monthlyData={monthlyData}/>} 
    {tab==='ziele' && <Goals avg={avg} net={net}/>} 
  </main>
}
function Kpi({icon,label,value,sub}){return <div className="card kpi"><div className="icon">{icon}</div><small>{label}</small><h2>{value}</h2><p>{sub}</p></div>}
function Card({title,sub,children}){return <div className="card"><h2>{title}</h2><p>{sub}</p>{children}</div>}
function Insight({icon,title,text}){return <div className="insight"><span>{icon}<b>{title}</b></span><p>{text}</p></div>}
function Portfolio(){return <div className="card tablewrap"><h2>Portfolio</h2><p>Manuelle Positionen mit Dividendenlogik</p><table><thead><tr><th>Unternehmen</th><th>Land</th><th>Sektor</th><th>Stück</th><th>Div./Aktie</th><th>Netto/Jahr</th><th>Yield on Cost</th></tr></thead><tbody>{holdings.map(h=><tr key={h.ticker}><td><b>{h.company}</b><small>{h.ticker} · {h.frequency}</small></td><td>{h.country}</td><td>{h.sector}</td><td>{h.shares}</td><td>{h.dividend.toFixed(2)} €</td><td><strong>{fmt(annualNet(h))}</strong></td><td>{yoc(h).toFixed(1)}%</td></tr>)}</tbody></table></div>}
function Calendar({monthlyData}){return <div className="months">{monthlyData.map(m=><div className="card" key={m.month}><div className="monthtitle"><h2>{m.month}</h2><CalendarDays color="#34d399"/></div><h3>{fmt(m.netto)}</h3><p>{fmt(m.brutto)} brutto</p>{holdings.filter(h=>h.months.includes(m.month)).map(h=><div className="row mini" key={h.ticker}><span>{h.company}</span><strong>{fmt(monthlyNet(h))}</strong></div>)}</div>)}</div>}
function Goals({avg,net}){return <div className="grid half"><Card title="Zielplanung" sub="Vom aktuellen Cashflow zum monatlichen Einkommen"><div className="bigbox"><small>Aktueller Netto-Monatsdurchschnitt</small><h1>{fmt(avg)}</h1><p>Ziel langfristig: 500 € netto pro Monat</p></div>{[500,1000,2000].map(t=><div key={t} className="goalitem"><div><span>{t} €/Monat</span><span>{Math.round(avg/t*100)}%</span></div><div className="bar"><i style={{width:`${Math.min(100,Math.round(avg/t*100))}%`}}/></div></div>)}</Card><Card title="Simulation" sub="Was passiert, wenn du deine Positionen erhöhst?">{[[1.1,'+10% Stückzahl'],[1.25,'+25% Stückzahl'],[1.5,'+50% Stückzahl']].map(([f,t])=><div className="row" key={t}><div><b>{t}</b><small>erwartete Netto-Jahresdividende</small></div><strong>{fmt(net*f)}</strong></div>)}</Card></div>}
createRoot(document.getElementById('root')).render(<App/>);
