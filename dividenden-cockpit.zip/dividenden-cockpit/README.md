# Dividenden-Cockpit

Persönlicher Dividenden-App-Prototyp mit Dashboard, Portfolio, Dividendenkalender und Zielplanung.

## Lokal starten
```bash
npm install
npm run dev
```

## Auf Vercel deployen
1. Repository auf GitHub erstellen.
2. Diese Dateien hochladen.
3. In Vercel: Add New Project -> GitHub Repository auswählen -> Deploy.

Die App nutzt aktuell Beispielwerte. Echte Depotdaten können später ergänzt werden.
